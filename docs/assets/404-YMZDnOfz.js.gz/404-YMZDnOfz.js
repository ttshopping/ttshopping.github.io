import{_ as e}from"./plugin-vueexport-helper-DlAUqK2U.js";const c={};function n(r,t){return Vue.openBlock(),Vue.createElementBlock("div",null,"404")}const _=e(c,[["render",n]]);export{_ as default};
